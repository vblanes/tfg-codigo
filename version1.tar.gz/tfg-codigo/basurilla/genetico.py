
def fitness(individuo):
    '''
    Funcion fitness del algoritmo genetico:
    se encarga de dar un valor entero a una instancia del problema
    '''
    return 1
def generacion_inicial(tamanyo_pool):
    '''
    metodo que crea la primera generacion de individuos
    '''
    poblacion = []
    for i in range(tamanyo_poblacion):
        poblacion.append(sorted([x for x in range(tamanyo_pool)],
        key = lambda k:random.random()))
    return poblacion

def reproduccion(ind1, ind2):
    #mitad aritmetica del array
    mitad = int(len(ind1)/2)
    #primera parte del primero
    primera_parte = ind1[:mitad]
    #segunda parte del segundo
    segunda_parte = ind2[mitad:]
    #por cada elemento de la segunda mitad
    for elem in segunda_parte:
        #si no esta en la primera parte lo anyado
        if elem not in primera_parte:
            primera_parte.append(elem)
        #si esta, busco uno que no este
        else:
            for a2 in ind2:
                if a2 not in primera_parte:
                    primera_parte.append(a2)
                    break
    return primera_parte


def mutacion():
    pass

def eleccion_estocastica(valores_fitness):
    '''
    Devuelve una tupla con los indices de dos padres
    '''
    padre1 = None
    padre2 = None
    tirada_estocastica = random.randint(1,np.sum(valores_fitness))
    for i in range(len(valores_fitness)):
        tirada_estocastica-=valores_fitness[i]
        if tirada_estocastica<=0:
            padre1 = i
            break
    #busco el segundo progenitor, no puede ser el mismo
    while(True):
        tirada_estocastica = random.randint(1,np.sum(valores_fitness))
        for i in range(len(valores_fitness)):
            tirada_estocastica-=valores_fitness[i]
            if tirada_estocastica<=0:
                padre2 = i
                break
        if padre2 != padre1:
            break
    return tuple((padre1, padre2))

def main(pool, pasosgeneracionales):
    '''
    Metodo principal del generador que dirige los pasos generacionales
    hace uso de todos los otros metodos para obtener una solucion heuristica
    pool: lista de cartas disponibles
    '''
    #crea el grafo de valores
    grafo = construye_grafo(pool)
    poblacion = generacion_inicial(len(pool))
    mejor_individuo = None
    mejor_fitness = -1
    pasos_desde_cambio = 0
    #empezamos a interar
    for paso in range(pasosgeneracionales):
        #calcula el fitness de los individuos
        valores = list(map(fitness, poblacion))
        max_generacional = max(valores)
        if max_generacional >= mejor_fitness:
            mejor_fitness = max_generacional
            mejor_individuo = poblacion[valores.index(max_generacional)]
            pasos_desde_cambio = 0
        else:
            pasos_desde_cambio+=1
        #se eligen los que van a reproducirse
        #se permite permitaciones pues si el tamanyo del array no es par
        #los hijos no serian clones exactos
        progenitores = set()
        while (len(progenitores)<50):
            progenitores.add(eleccion_estocastica(valores))
        #se crean los individuos de la siguiente generacion_inicial
        siguiente_generacion = []
        progenitores = list(progenitores)
        for i in range(50):
            #todo este churro porque los progenitores son una lista indices
            #al final tenemos que ir a parar a la poblacion
            siguiente_generacion.append(
            reproduccion(poblacion[progenitores[i][0]],
            poblacion[progenitores[i][1]]))
            #cada dos padres tienen que haber dos hijos
            siguiente_generacion.append(
            reproduccion(poblacion[progenitores[i][1]],
            poblacion[progenitores[i][0]]))
        #
    print(mejor_individuo)




def test():
    g = Generador()
    p = []
    for i in range(6):
        p = p + g.simular_sobre()
    main(p, 10000)

if __name__ == '__main__':
    test()

