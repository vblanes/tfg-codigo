from carta import Carta
from graph import Graph
from generador_sobres import Generador
import operacionesbd as bd
import random
import numpy as np
import copy

#porcentaje de peso de la arista y el nodo destino
por_nodo = 0.7
por_arista = 0.5
peso_cmc = 0.2

def construye_grafo(cartas):
    '''
    Dada una lista de cartas (las que tocan en el sobre)
    el metodo devuelve el grafo con los valores de la bd
    '''
    grafo = Graph()
    #anyado los vertices del grafo
    for carta in cartas:
        #si ya tengo un nodo con el mismo nombre hago tratamiento
        if grafo.get_node(carta) is None:
            grafo.add_node(carta)
        else:
            grafo.add_node(copy.copy(carta))
    #anyado las Sinergias
    nodos = grafo.nodes
    #todos contra todos
    for carta1 in nodos:
        pesos = []
        #dado un nodo calculamos los pesos para todo el resto
        for carta2 in nodos:
            pesos.append(bd.valor_sinergia(carta1.name, carta2.name))
        #anyadimos las aristas a dicho nodo
        carta1.add_multiple_edges(nodos, pesos)
    return grafo

def suma_valores(cartas):
    sumatorio = 0
    for c in cartas:
        sumatorio+=c.nota_fireball
    return sumatorio

def func_valor(arista):
    '''
    Funcion de evaluacion que da un valor subjetivo de una cartas
    '''
    #TODO --> afinado de la funcion
    return (arista[0].name.nota_fireball*por_nodo + arista[1]*por_arista
            - arista[0].name.cmc()*peso_cmc)
def colores_compatibles(colores, nodoposible):
    '''
    Funcion para saber si los colores de un vecino son compatibles con
    los colores sobre el que estoy construyendo el mazo
    '''
    if nodoposible.name.color in colores or nodoposible.name.color == 'I':
        return True
    elif nodoposible.name.color == 'M':
        for c in list(nodoposible.name.coste_mana):
            if not(c == 'X' or c.isdigit() or c in colores):
                return False
        return True
    else:
        return False


def algoritmo_constructor(pool, ncartas=23):
    #monta el grafo
    grafo = construye_grafo(pool)
    #buscamos los dos colores con mejor puntuacion individual
    nodos = grafo.nodes
    colores = ['B', 'W', 'G', 'U', 'R']
    valores =  [0, 0, 0, 0, 0]
    for c in range(len(colores)):
        for n in nodos:
            if n.name.color == colores[c]:
                valores[c]+=n.name.nota_fireball
    #me quedo con los 2 mejores colores -> TODO
    colores = [x for (y,x) in sorted(zip(valores,colores), reverse=True)][0:2]
    #busco primer nodo
    actual = None
    visitados = set()
    for nodo in nodos:
        if nodo.name.color == colores[0]:
            actual = nodo
            break
    visitados.add(actual)
    while(len(visitados)<ncartas):
        posibilidades = sorted(actual.edge_list(), key=lambda k:func_valor(k), reverse=True)
        for pos in posibilidades:
            if colores_compatibles(colores, pos[0]) and pos[0] not in visitados:
                actual = pos[0]
                visitados.add(actual)
                break
    pinta(list(visitados))



def pinta(lista):
    lista = sorted(lista, key=lambda k:(k.name.color, k.name.cmc(), k.name.nombre))
    for l in lista:
        print(l.name)

def test():
    pool = []
    g = Generador()
    for i in range(6):
        pool = pool+g.simular_sobre()
    lista = sorted(pool, key=lambda k:(k.color, k.cmc(), k.nombre))
    print('POOL\n#####################')
    for c in lista:
        print(c)
    print('\n####################\n ELECÇAO\n##################')
    algoritmo_constructor(pool)

if __name__ == '__main__':
    test()
